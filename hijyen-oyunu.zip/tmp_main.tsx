﻿import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=afa8c616"; const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=afa8c616"; const StrictMode = __vite__cjsImport1_react["StrictMode"];
import "/src/i18n/index.ts";
import __vite__cjsImport3_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=afa8c616"; const createRoot = __vite__cjsImport3_reactDom_client["createRoot"];
import "/src/index.css";
import App from "/src/App.tsx";
createRoot(document.getElementById('root')).render(/*#__PURE__*/ _jsxDEV(StrictMode, {
    children: /*#__PURE__*/ _jsxDEV(App, {}, void 0, false, {
        fileName: "C:/Users/QP Super/Desktop/Hijyen Oyunu/src/main.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this)
}, void 0, false, {
    fileName: "C:/Users/QP Super/Desktop/Hijyen Oyunu/src/main.tsx",
    lineNumber: 8,
    columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCAnLi9pMThuJ1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnXG5pbXBvcnQgJy4vaW5kZXguY3NzJ1xuaW1wb3J0IEFwcCBmcm9tICcuL0FwcC50c3gnXG5cbmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSEpLnJlbmRlcihcbiAgPFN0cmljdE1vZGU+XG4gICAgPEFwcCAvPlxuICA8L1N0cmljdE1vZGU+LFxuKVxuIl0sIm5hbWVzIjpbIlN0cmljdE1vZGUiLCJjcmVhdGVSb290IiwiQXBwIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFVBQVUsUUFBUSxRQUFPO0FBQ2xDLE9BQU8sU0FBUTtBQUNmLFNBQVNDLFVBQVUsUUFBUSxtQkFBa0I7QUFDN0MsT0FBTyxjQUFhO0FBQ3BCLE9BQU9DLFNBQVMsWUFBVztBQUUzQkQsV0FBV0UsU0FBU0MsY0FBYyxDQUFDLFNBQVVDLE1BQU0sZUFDakQsUUFBQ0w7Y0FDQyxjQUFBLFFBQUNFIn0=
